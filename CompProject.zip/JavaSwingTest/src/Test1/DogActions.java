/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test1;

/**
 *
 * @author ricky
 */
public class DogActions {
    private final String ID;
    private final String DogName;
    private final String breakfast;
    private final String BathroomBreak1;
    private final String walk;
    private final String lunch;
    private final String BathroomBreak2;
    private final String dinner;
    private final String BathroomBreak3;
    private final String playtime;

    public DogActions(String ID,String DogName, String breakfast, String BathroomBreak1, String walk, String lunch, String BathroomBreak2, String dinner, String BathroomBreak3, String playtime) {
      this.ID = ID;
        this.DogName = DogName;
       
        this.breakfast = breakfast;
        this.BathroomBreak1 = BathroomBreak1;
        this.walk = walk;
        this.lunch = lunch;
        this.BathroomBreak2 = BathroomBreak2;
        this.dinner = dinner;
        this.BathroomBreak3 = BathroomBreak3;
        this.playtime = playtime;
    }

    public String getID() {
        return ID;
    }

    
    public String getDogName() {
        return DogName;
    }

    

    public String getBreakfast() {
        return breakfast;
    }

    public String getBathroomBreak1() {
        return BathroomBreak1;
    }

    public String getWalk() {
        return walk;
    }

    public String getLunch() {
        return lunch;
    }

    public String getBathroomBreak2() {
        return BathroomBreak2;
    }

    public String getDinner() {
        return dinner;
    }

    public String getBathroomBreak3() {
        return BathroomBreak3;
    }

    public String getPlaytime() {
        return playtime;
    }
    
    
}
