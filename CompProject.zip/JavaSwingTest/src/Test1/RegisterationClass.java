/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test1;

import java.util.Scanner;
import javax.swing.JOptionPane;
import java.awt.event.WindowEvent;
/**
 *
 * @author ricky
 */
public class RegisterationClass {
 
    public String NewUsername;
    public char[] NewPassword;
    
    
    public RegisterationClass (String NewUsername, char[] NewPassword)
    {
        this.NewUsername = NewUsername;
        this.NewPassword = NewPassword;
    }
    
    public boolean PasswordCorrect(String password)
    {
         if (password.length() >7)
         {
             if(checkPass(password))
             {
                 return true;
             }
             else
             {
                 return false;
             }
                       
         }
         else
         {
            JOptionPane.showMessageDialog(null, "Please Enter Password With At Least 8 Characters");
            return false;
         }
    }
    
    public boolean checkPass (String password)
    {
        boolean hasNum = false; 
        boolean hasCap = false;
        boolean hasLow = false;
        char c;
        for (int i = 0; i < password.length(); i++) {
            c = password.charAt(i);
            if (Character.isDigit(c)) {
                hasNum = true;
            }
            else if (Character.isUpperCase(c))
            {
                hasCap = true;
            }
            else if (Character.isLowerCase(c))
            {
                hasLow = true;
            }
            if(hasNum && hasCap && hasLow)
            {
                return true;
            }
                
    }
    return false;
}
    
    
}
